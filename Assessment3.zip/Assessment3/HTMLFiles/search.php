<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <link rel="stylesheet" href="../CSSFiles/desktop.css" media="screen and (min-width:1024px)" />
    <link rel="stylesheet" href="../CSSFiles/mobile.css" media="screen and (max-width:600px)" />
    <link rel="stylesheet" href="../CSSFiles/tablet.css" media="screen and (max-width:768px)" />

    <title> Student Portal</title>
    <link rel="icon" href="../Images/logo1.png" type="image/x-icon">

</head>

<body>

    <search>
        <!-- <form action="/search" method="get"> -->
        <form id="searchForm" action="search.php" method="get">
            <input type="search" id="query" name="q" placeholder="Type keywords... ">
            <button type="submit">Search</button>
        </form>
        <div id="searchResults"></div>
    </search>
    <main class="main">
        <section class="course-wrapper">
            <section class="dashboard-header">
                <h2>Global Search</h2><br><br><br><br>
                        
                    
            </section>
            <p class="pargraph"><a href="../HTMLFiles/index.php"> Back to dashboard</p>
    </main>
    <script src="../JAVASCRIPT/JavaScript.js"></script>
</body>

</html>