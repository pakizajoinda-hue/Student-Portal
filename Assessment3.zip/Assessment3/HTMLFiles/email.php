<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <title> Student Portal</title>
    <link rel="icon" href="../Images/logo1.png" type="image/x-icon">
</head>

<body>
        <header class="mobile-header">
        <input class="menu-chkbx" type="checkbox" id="menu-chkbx" hidden/>
        <label class="menu-burger" for="menu-chkbx">
            <span class="hamburger" hidden></span></label>
        <nav class="main-nav">
            <ul class="nav-list">

                <li class="logo"></li>
                <img src="../Images/logo.png" alt="Logo" width="106">
                </li>
                <li class="search"><a href="search.php">
                        <img src="../Images/iconsearch.png" alt="search" width="20"></a></li>
                </li>
                <li class="dashboard"><a href="index.php"> Dashboard </a></li>
                <li><a href="enrolment.php">Enrolment </a></li>
                <li><a href="student_details.php"> Student Details </a></li>
                <li><a href="results.php"> Results </a></li>
                <li><a href="Support.php"> Support </a></li>
                <li class="dropdown">
                    <details>
                        <summary>PG</summary>
                        <ul class="dropdown-menu">
                            <li>Profile</li>
                            <li>Grand</li>
                            <li>Calandar</li>
                            <li>Message</li>
                            <li>Report</li>
                            <li>Log Out</li>

                        </ul>
                    </details>
                </li>
            </ul>
    </nav></header>
    </div>




    <!-- Students Result -->

    <section class="details">
        <nav class="meunSD">
            <h1>PG</h1>
            <h2>Pakeza GOINDA</h2>

        </nav>
        <div class="student_detalis">
            <!-- <h1>Hwe</h1> -->
        </div>


    </section>
    
    </div>
</body>

</html>