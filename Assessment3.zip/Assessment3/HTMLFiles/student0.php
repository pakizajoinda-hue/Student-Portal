<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <title> Student Portal</title>
    <link rel="icon" href="../Images/logo1.png" type="image/x-icon">
</head>

<body>
    <nav class="main-nav">
        <ul class="nav-list">

            <li class="logo"></li>
            <img src="../Images/logo.png" alt="Logo" width="106">
            </li>
            <li class="search"><a href="search.php">
                    <img src="../Images/iconsearch.png" alt="search" width="20"></a></li>

            </li>
                <li class="dashboard"><a href="index.php"> Dashboard </a></li>

            <li><a href="enrolment.php"> Enrolment </a></li>
            <li><a href="student_details.php"> Student Details </a></li>
            <li><a href="results.php"> Results </a></li>
            <li><a href="Support.php"> Support </a></li>

            <li class="dropdown">
                <details>
                    <summary>PG</summary>
                    <ul class="dropdown-menu">
                        <li>Profile</li>
                        <li>Grand</li>
                        <li>Calandar</li>
                        <li>Message</li>
                        <li>Report</li>
                        <li>Log Out</li>

                    </ul>
                </details>
            </li>
        </ul>
    </nav>

    </div>
      <section class="congr">
    <div class="cong">
      <h1>Welcome to Students Portal</h1>
<h4>Get start with mychisholm</h4>
    </div> </section>
    <footer class="foot">
        Copyright &copy; (2026)
    </footer>

      </main>

</body>

</html>