<?php
require_once __DIR__ . '/../PHP/auth.php';

requireEnrolledStudent();



require_once __DIR__ . '/../PHP/auth.php';
require_once __DIR__ . '/../PHP/db.php';

$perPage = 4;
$courses = [
    ['title' => '0. Getting started with myChisholm', 'category' => 'Students', 'image' => 'chish1.png', 'link' => 'student0.php', 'class' => 'course-img1'],
    ['title' => '1. Student Orientation', 'category' => 'Students', 'image' => 'chish.png', 'link' => 'studentOrintation.php', 'class' => 'course-img2'],
    ['title' => '2. Students New Central', 'category' => 'Students', 'image' => 'new.png', 'link' => 'studentNews.php', 'class' => 'course-img3'],
    ['title' => 'ITS101: Information System (25-2026)', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS101.php', 'class' => 'course-img4'],
    ['title' => 'ITS102: Programming Environment (25-2026)', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS102.php', 'class' => 'course-img5'],
    ['title' => 'ITS103: Database Fundamentals (25-2026)', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS103.php', 'class' => 'course-img6'],
    ['title' => 'ITS104: Introduction to Cyber Security (25-2026)', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS104.php', 'class' => 'course-img7'],
    ['title' => 'ITS201: Inside Information Technology (25-2026)', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS201.php', 'class' => 'course-img8'],
    ['title' => 'ITS202: Math Foundations for Computing (25-2026)', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS202.php', 'class' => 'course-img9'],
    ['title' => 'ITS203: System and Network Administration (25-2026)', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS203.php', 'class' => 'course-img10'],
    ['title' => 'ITS204: Web Technologies and Full-Stack Fundamentals', 'category' => '[C] Common Units (IT 2025)', 'image' => 'green.png', 'link' => 'ITS204.php', 'class' => 'course-img11'],
    ['title' => 'Tertiary Access Program', 'category' => '[TAP] Tertiary Access Program', 'image' => 'ter.png', 'link' => 'tertairy.php', 'class' => 'course-img12'],
];
$totalCourses = count($courses);
$totalPages = max(1, (int) ceil($totalCourses / $perPage));
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = ($page && $page > 0) ? min($page, $totalPages) : 1;
$offset = ($page - 1) * $perPage;
$pageCourses = array_slice($courses, $offset, $perPage);

$studentName = '';
$studentInitials = 'ST';
if (!empty($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'student') {
    try {
        $stmt = $pdo->prepare(
            "SELECT s.first_name, s.last_name
             FROM users u
             JOIN students_full s ON s.id = u.student_id
             WHERE u.id = ? AND u.enrollment_completed = 1
             LIMIT 1"
        );
        $stmt->execute([$_SESSION['user_id']]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($student) {
            $studentName = trim($student['first_name'] . ' ' . $student['last_name']);
            $studentInitials = strtoupper(mb_substr($student['first_name'], 0, 1) . mb_substr($student['last_name'], 0, 1));
        }
    } catch (PDOException $e) {
        error_log($e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <link rel="stylesheet" href="../CSSFiles/desktop.css" media="screen and (min-width:1024px)" />
    <link rel="stylesheet" href="../CSSFiles/mobile.css" media="screen and (max-width:600px)" />
    <link rel="stylesheet" href="../CSSFiles/tablet.css" media="screen and (min-width:601px) and (max-width:768px)" />
    
    <title> Student Portal</title>
    <link rel="icon" href="../Images/logo1.png" type="image/x-icon">

</head>

<body>
    <header class="mobile-header">
        <input class="menu-chkbx" type="checkbox" id="menu-chkbx" hidden/>
        <label class="menu-burger" for="menu-chkbx">
            <span class="hamburger" hidden></span></label>
        <nav class="main-nav">
            <ul class="nav-list">

                <li class="logo"></li>
                <img src="../Images/logo.png" alt="Logo" width="106">
                </li>
                <li class="search"><a href="search.php">
                        <img src="../Images/iconsearch.png" alt="search" width="20"></a></li>
                </li>
                <li class="dashboard"><a href="index.php"> Dashboard </a></li>
                <li><a href="enrolment.php">Enrolment </a></li>
                <li><a href="student_details.php"> Student Details </a></li>
                <li><a href="results.php"> Results </a></li>
                <li><a href="Support.php"> Support </a></li>
                <li class="dropdown">
                    <details>
                        <summary><?= htmlspecialchars($studentInitials, ENT_QUOTES, "UTF-8") ?></summary>
                        <ul class="dropdown-menu">
                            <li>Profile</li>
                            <li>Grand</li>
                            <li>Calandar</li>
                            <li>Message</li>
                            <li>Report</li>
                            <li><a href="../PHP/logout.php" style="color: black">Log Out</a></li>

                        </ul>
                    </details>
                </li>
            </ul>
    </nav></header>
    </div>

    <main class="main">
        <section class="course-wrapper">
            <section class="dashboard-header">
                <h3>Welcome to the Student Portal</h3>
                <h2><span id="student-greeting">
                    <?= $studentName !== "" ? "Hi, " . htmlspecialchars(explode(" ", $studentName)[0], ENT_QUOTES, "UTF-8") . "!" : "Hi!" ?></span></h2>
            </section>

            <section class="started-courses">
                <h3> Started Courses </h3>
                <img class="imageicon" src="../Images/screan.png" alt="courseicon" width="100px">
                <p class="text"> No started courses</p>
                <div class="course">

                </div>
                <div class="course"></div>
            </section>


            <section class="course-overview">
                <h3> Course Overview </h3>
                <div class="course-control">

                    <select>
                        <option value="all">All</option>
                        <option value="in progress">In Progress</option>
                        <option value="past">Past</option>
                        <option value="future">Future</option>



            </section>
            <input id="courseSearch" type="search" placeholder="Search Courses" aria-label="Search Course">
            <select>

                <option value="sord">Sord by course name</option>
                <option value="name">Sord by name</option>
                <option value="last">Sord by last name</option>
            </select>

            <select>
                <option value="card">Card</option>
                <option value="list">List</option>
                <option value="summary">Summary</option>
            </select>


            </div>

            <div>
                <div class="bar">
                <div id="container">
                    <?php foreach ($pageCourses as $course): ?>
                    <div class="course-card">
                        <nav class="navcourse">
                            <a href="<?= htmlspecialchars($course['link'], ENT_QUOTES, 'UTF-8') ?>">
                                <img class="<?= htmlspecialchars($course['class'], ENT_QUOTES, 'UTF-8') ?>"
                                     src="../Images/<?= htmlspecialchars($course['image'], ENT_QUOTES, 'UTF-8') ?>"
                                     alt="<?= htmlspecialchars($course['title'], ENT_QUOTES, 'UTF-8') ?>">
                            </a>
                        </nav>
                        <p><?= htmlspecialchars($course['title'], ENT_QUOTES, 'UTF-8') ?></p>
                        <p class="students"><?= htmlspecialchars($course['category'], ENT_QUOTES, 'UTF-8') ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <nav class="pagination" aria-label="Course pages">
                <a class="page-link <?= $page <= 1 ? 'disabled' : '' ?>"
                   href="?page=<?= max(1, $page - 1) ?>" <?= $page <= 1 ? 'aria-disabled="true" tabindex="-1"' : '' ?>>Previous</a>
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <a class="page-link <?= $p === $page ? 'active' : '' ?>"
                       href="?page=<?= $p ?>" <?= $p === $page ? 'aria-current="page"' : '' ?>><?= $p ?></a>
                <?php endfor; ?>
                <a class="page-link <?= $page >= $totalPages ? 'disabled' : '' ?>"
                   href="?page=<?= min($totalPages, $page + 1) ?>" <?= $page >= $totalPages ? 'aria-disabled="true" tabindex="-1"' : '' ?>>Next</a>
            </nav>

        </section>

    </main>
<script src="../JAVASCRIPT/JavaScript.js"></script>

</body>

</html>