<?php
require_once __DIR__ . '/../PHP/auth.php';

requireEnrolledStudent();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <link rel="stylesheet" href="../CSSFiles/desktop.css" media="screen and (min-width:1024px)" />
    <link rel="stylesheet" href="../CSSFiles/mobile.css" media="screen and (max-width:600px)" />
    <link rel="stylesheet" href="../CSSFiles/tablet.css"  media="screen and (min-width:601px) and (max-width:768px)"/>
    <title> Student Portal</title>
    <link  rel="icon" href="../Images/logo1.png" type="image/x-icon">
    
</head>
<body>
        <header class="mobile-header">
        <input class="menu-chkbx" type="checkbox" id="menu-chkbx" hidden/>
        <label class="menu-burger" for="menu-chkbx">
            <span class="hamburger" hidden></span></label>
        <nav class="main-nav">
            <ul class="nav-list">

                <li class="logo"></li>
                <img src="../Images/logo.png" alt="Logo" width="106">
                </li>
                <li class="search"><a href="search.php">
                        <img src="../Images/iconsearch.png" alt="search" width="20"></a></li>
                </li>
                <li class="dashboard"><a href="index.php"> Dashboard </a></li>
                <li><a href="enrolment.php">Enrolment </a></li>
                <li><a href="student_details.php"> Student Details </a></li>
                <li><a href="results.php"> Results </a></li>
                <li><a href="Support.php"> Support </a></li>
                <li class="dropdown">
                    <details>
                        <summary><span id="student-initials">ST</span></summary>
                        <ul class="dropdown-menu">
                            <li>Profile</li>
                            <li>Grand</li>
                            <li>Calandar</li>
                            <li>Message</li>
                            <li>Report</li>
                            <li><a href="../PHP/logout.php" style="color: black">Log Out</a></li>

                        </ul>
                    </details>
                </li>
            </ul>
    </nav></header>
    </div>

    <!-- Students Result -->

    <section class="details">
        <nav class="meunSD">
            <h1><span id="student-initials">ST</span></h1>
            <h2><span id="student-full-name">Student</span></h2>

        </nav>
        <div class="student_result">

            <h3>Courses I am taking</h3>

            <table class="table">
                <tr>
                    <th>Course name</th>
                    <th>Grade</th>

            
                <tr>
                    <td><a href="../HTMLFiles/tertairy.php">Tertiary Access Program</a></td>
                    <td></td>
                </tr>

                <tr>
                    <td><a href="../HTMLFiles/ITS101.php"> ITS101: Information System (25-2026)</a></td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/ITS102.php">ITS102: Programming Environment (25-2026)</a></td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/ITS103.php">ITS103: Database Fundamentals (25-2026)</a></td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/ITS104.php">ITS104: Introduction to Cyber Security (25-2026)</a></td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/ITS201.php"> ITS201: Inside Information Technology (25-2026)</a></td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/ITS202.php">ITS202: Math Foundation for Computing (25-2026)</a></td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/ITS203.php">ITS203: System and Network Administration (25-2026)</a></td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/ITS204.php">ITS204: Web Technology and Full-Stack Fundation (25-2026)</a>
                    </td>
                    <td>100.00</td>
                </tr>
                <tr>
                    <td><a href="../HTMLFiles/student0.php">0. Getting started with mychisholm</a>
                    </td>
                    <td>100.00</td>
                </tr>

                <tr>
                    <td><a href="../HTMLFiles/studentOrintation.php">1. Student Orintation</a>
                    </td>
                    <td></td>
                </tr>

            </table>

    </section>
    </div>
    </div>
    </div>
<script>
fetch("../PHP/student_profile.php", {
    credentials: "same-origin"
})
.then(response => {
    if (!response.ok) {
        throw new Error("Unable to load student profile");
    }
    return response.json();
})
.then(student => {
    const firstName = (student.first_name || "").trim();
    const lastName = (student.last_name || "").trim();
    const fullName = (firstName + " " + lastName).trim();
    const initials = (
        firstName.charAt(0) + lastName.charAt(0)
    ).toUpperCase();

    document.querySelectorAll("#student-initials").forEach(element => {
        element.textContent = initials || "ST";
    });

    document.querySelectorAll("#student-full-name").forEach(element => {
        element.textContent = fullName || "Student";
    });

    const email = document.getElementById("student-email");
    if (email) {
        email.textContent = student.email || "";
    }

    const emailLink = document.getElementById("student-email-link");
    if (emailLink && student.email) {
        emailLink.href = "mailto:" + student.email;
    }
})
.catch(error => {
    console.error("Student profile error:", error);
});
</script>
</body>

</html>