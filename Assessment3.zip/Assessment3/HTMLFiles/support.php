<?php
require_once __DIR__ . '/../PHP/auth.php';

requireEnrolledStudent();
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <link rel="stylesheet" href="../CSSFiles/desktop.css" media="screen and (min-width:1024px)" />
    <link rel="stylesheet" href="../CSSFiles/mobile.css" media="screen and (max-width:600px)" />
    <link rel="stylesheet" href="../CSSFiles/tablet.css"  media="screen and (min-width:601px) and (max-width:768px)"/>
    <title> Student Portal</title>
    <link  rel="icon" href="../Images/logo1.png" type="image/x-icon">
    
</head>

<body>
        <header class="mobile-header">
        <input class="menu-chkbx" type="checkbox" id="menu-chkbx" hidden/>
        <label class="menu-burger" for="menu-chkbx">
            <span class="hamburger" hidden></span></label>
        <nav class="main-nav">
            <ul class="nav-list">

                <li class="logo"></li>
                <img src="../Images/logo.png" alt="Logo" width="106">
                </li>
                <li class="search"><a href="search.php">
                        <img src="../Images/iconsearch.png" alt="search" width="20"></a></li>
                </li>
                <li class="dashboard"><a href="index.php"> Dashboard </a></li>
                <li><a href="enrolment.php">Enrolment </a></li>
                <li><a href="student_details.php"> Student Details </a></li>
                <li><a href="results.php"> Results </a></li>
                <li><a href="Support.php"> Support </a></li>
                <li class="dropdown">
                    <details>
                        <summary><span id="student-initials">ST</span></summary>
                        <ul class="dropdown-menu">
                            <li>Profile</li>
                            <li>Grand</li>
                            <li>Calandar</li>
                            <li>Message</li>
                            <li>Report</li>
                            <li><a href="../PHP/logout.php" style="color: black">Log Out</a></li>

                        </ul>
                    </details>
                </li>
            </ul>
    </nav></header>
    </div>


        <div class="support">
            <img src="../Images/3.jpg" alt="support">
        </div>

        <div class="container">
            <div class="left">
                <p class="support-title">Support</p>
                <p>Need help? Our support team is here for you.</p>
                <p>Contact us <a href="https://www.chisholm.edu.au/industry/contact-our-industry-specialists"> email</a>
                    for
                    assistance with any technical</p>
                <p> issues, account inquiries, or general questions.</p>
                <p>We are committed to providing prompt and effective</p>
                <p> support to ensure your experience is smooth and hassle-free.</p>
            </div>

            <div class="right">
                <p class="technical-support">Technical support</p>
                <p>For technical support, please reach out to
                    our dedicated team via email at
                    <a href="mailto:support@university.edu">support@university.edu</a>
                <p>or call us at (123) 456-7890. Our suppor
                    hours are Monday to Friday, 9 AM to 5 PM.</p>
                </p>
            </div>
        </div>

        <form onsubmit="return register()" class="support-form">
            <fieldset field>
                <legend class="leg">
                    <h2>Contact us or submit an enquiry</h2>
                </legend>
                <div>
                </div>

                <div class="input-box">

                    <label for="fname">First Name *</label>
                    <input type="text" id="fname" name="fname" placeholder="" />
                </div>
                <div class="input-box">
                    <label for="lname">Last Name *</label>
                    <input type="text" id="lname" name="lname" placeholder="" />
                </div>
                <div class="input-box">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" placeholder="" />
                </div>
                <div class="input-box">
                    <label for="phone">Phone *</label>
                    <input type="tel" id="phone" name="phone" placeholder="" /><br>
                </div>
                <br>
                <div>
                    <div>
                        <label>Gender: </label><br><br>
                        <label for="genderM">Male </label>
                        <input type="radio" id="genderM" name="gender" value="Male" required></label>

                    </div>
                    <div>
                        <label for="genderF">Female</label>
                        <input type="radio" id="genderF" name="gender" value="Female" required></label>

                        <div><textarea class="textarea" name="message" rows="10" cols="30">
                            Your message here...</textarea></div>
                        </textarea>
                    </div>

                    <input class="subm" type="submit" value="Submit" />
                </div>
            </fieldset>
        </form>
    </div>
    </div>

<img class="footerpic" src="../Images/footerpic.png" alt="support">
    <footer>
        <p>© 2026 Student Portal.</p>
    </footer>

<script>
fetch("../PHP/student_profile.php", {
    credentials: "same-origin"
})
.then(response => {
    if (!response.ok) {
        throw new Error("Unable to load student profile");
    }
    return response.json();
})
.then(student => {
    const firstName = (student.first_name || "").trim();
    const lastName = (student.last_name || "").trim();
    const fullName = (firstName + " " + lastName).trim();
    const initials = (
        firstName.charAt(0) + lastName.charAt(0)
    ).toUpperCase();

    document.querySelectorAll("#student-initials").forEach(element => {
        element.textContent = initials || "ST";
    });

    document.querySelectorAll("#student-full-name").forEach(element => {
        element.textContent = fullName || "Student";
    });

    const email = document.getElementById("student-email");
    if (email) {
        email.textContent = student.email || "";
    }

    const emailLink = document.getElementById("student-email-link");
    if (emailLink && student.email) {
        emailLink.href = "mailto:" + student.email;
    }
})
.catch(error => {
    console.error("Student profile error:", error);
});
</script>
</body>

</html>