<?php

require_once __DIR__ . '/../PHP/auth.php';

if (empty($_SESSION['user_id']) || empty($_SESSION['role'])) {
    header('Location: ../PHP/login.php');
    exit;
}
 ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <link rel="stylesheet" href="../CSSFiles/desktop.css" media="screen and (min-width:1024px)" />
    <link rel="stylesheet" href="../CSSFiles/mobile.css" media="screen and (max-width:600px)" />
    <link rel="stylesheet" href="../CSSFiles/tablet.css" media="screen and (min-width:601px) and (max-width:768px)" />
    <title> Student Portal</title>
    <link rel="icon" href="../Images/logo1.png" type="image/x-icon">

</head>

<body>
      <header class="mobile-header">
        <input class="menu-chkbx" type="checkbox" id="menu-chkbx" hidden/>
        <label class="menu-burger" for="menu-chkbx">
            <span class="hamburger" hidden></span></label>
        <nav class="main-nav">
            <ul class="nav-list">

                <li class="logo"></li>
                <img src="../Images/logo.png" alt="Logo" width="106">
                </li>
                <li class="search"><a href="search.php">
                        <img src="../Images/iconsearch.png" alt="search" width="20"></a></li>
                </li>
               <li class="dashboard"><a href="index.php"> Dashboard </a></li>
                <li><a href="enrolment.php">Enrolment </a></li>
                <li><a href="student_details.php"> Student Details </a></li>
                <li><a href="results.php"> Results </a></li>
                <li><a href="Support.php"> Support </a></li>
                <li class="dropdown">
                    <details>
                         <summary><span id="student-initials">ST</span></summary>
                        <ul class="dropdown-menu">
                            <li>Profile</li>
                            <li>Grand</li>
                            <li>Calandar</li>
                            <li>Message</li>
                            <li>Report</li>
                            <li><a href="../PHP/logout.php" style="color: black">Log Out</a></li>

                        </ul>
                    </details>
                </li>
            </ul>
    </nav></header>
    </div>
    <div class="enrolment-box">
        <div class="enrolment">

           
                <video autoplay muted loop controls>
                <source src="../Videos/video_2026-08-25_12-52-02.mp4" type="video/mp4">
            </video>
            <H1>Welcome to Chisholm Enrolment Form</H1>
        </div>

        <!---Enrolment--->


        <form action="../PHP/save_student.php" method="POST" class="enrolment-form">
            <fieldset>
                <legend class="leg">
                    <h2>Apply for the course you'r interested in</h2>
                </legend>
                <div class="choice-section">
                </div>

                <div class="input-box">

                    <label for="fname">First Name *</label>
                    <input type="text" id="fname" name="first_name"/>
                </div>
                <div class="input-box">
                    <label for="lname">Last Name *</label>
                    <input type="text" id="lname" name="last_name"/>
                </div>
                <div class="input-box">
                    <label for="email">Email *</label>
                    <input type="text" id="email" name="email"/>
                </div>
                <div class="input-box">
                    <label for="phone">Phone *</label>
                    <input type="tel" id="phone" name="phone"/><br>
                </div>
                <br>
                <div>
                    <div>
                        <label>Gender: </label><br><br>
                        <label for="genderM">Male </label>
                        <input type="radio" id="genderM" name="gender" value="Male"></label>



                    </div>
                    <div>
                        <label for="genderF">Female</label>
                        <input type="radio" id="genderF" name="gender" value="Female"></label>


                    </div>
                    <br>
                    <select id="location" name="location">
                        <option value="" selected disabled>Location</option>
                        <option value="Dandenong">Dandenong</option>
                        <option value="Frankston">Frankston</option>
                        <option value="Berwick">Berwick</option>

                    </select>
                    <br><br>
                    <label> Courses: </label><br><br>

                    <label for="cpp">C++</label>
                    <input type="checkbox" id="cpp" name="courses[]" value="C++"><br>

                    <label for="java">JAVA</label>
                    <input type="checkbox" id="java" name="courses[]" value="JAVA"><br>

                    <label for="html">HTML</label>
                    <input type="checkbox" id="html" name="courses[]" value="HTML"><br>

                    <label for="python">Python</label>
                    <input type="checkbox" id="python" name="courses[]" value="Python"><br>

                    <label for="php">PHP</label>
                    <input type="checkbox" id="php" name="courses[]" value="PHP"><br><br>


                </div>


                <input class="sub" type="submit" value="Submit" />
                <link rel="stylesheed" href="../HTMLFiles/success.php"/>
    </div>

    </div>
    </fieldset>
</form>

    </div>
   
    </div>
    </div>
    </div>
    <script src="../JAVASCRIPT/JavaScript.js"></script>

    </script>

    <script>
fetch("../PHP/student_profile.php", {
    credentials: "same-origin"
})
.then(response => {
    if (!response.ok) {
        throw new Error("Unable to load student profile");
    }
    return response.json();
})
.then(student => {
    const firstName = (student.first_name || "").trim();
    const lastName = (student.last_name || "").trim();
    const fullName = (firstName + " " + lastName).trim();
    const initials = (
        firstName.charAt(0) + lastName.charAt(0)
    ).toUpperCase();

    document.querySelectorAll("#student-initials").forEach(element => {
        element.textContent = initials || "ST";
    });

    document.querySelectorAll("#student-full-name").forEach(element => {
        element.textContent = fullName || "Student";
    });

    const email = document.getElementById("student-email");
    if (email) {
        email.textContent = student.email || "";
    }

    const emailLink = document.getElementById("student-email-link");
    if (emailLink && student.email) {
        emailLink.href = "mailto:" + student.email;
    }
})
.catch(error => {
    console.error("Student profile error:", error);
});
</script>
</body>

</html>