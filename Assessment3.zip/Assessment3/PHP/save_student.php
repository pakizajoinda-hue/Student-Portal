<?php
require_once "auth.php";
requireStudent();
require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Error: Invalid request method.");
}

if (
    empty($_SESSION["user_id"]) ||
    !isset($_SESSION["enrollment_completed"]) ||
    (int)$_SESSION["enrollment_completed"] === 1
) {
    exit("You are not allowed to submit this enrolment.");
}

$first_name = trim($_POST["first_name"] ?? "");
$last_name = trim($_POST["last_name"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$gender = trim($_POST["gender"] ?? "");
$location = trim($_POST["location"] ?? "");
$courses = $_POST["courses"] ?? [];

if (!preg_match("/^[a-zA-Z]+$/", $first_name)) {
    exit("Error: First name must contain English letters only.");
}

if (!preg_match("/^[a-zA-Z]+$/", $last_name)) {
    exit("Error: Last name must contain English letters only.");
}

if (!preg_match('/^\+?[0-9]{10}$/', $phone)) {
    exit("Error: Please enter a valid phone number (10 digits, optionally with +).");
}

if (!in_array($gender, ["Male", "Female"], true)) {
    exit("Error: Please select a valid gender.");
}

$allowed_locations = ["Dandenong", "Frankston", "Berwick"];

if (!in_array($location, $allowed_locations, true)) {
    exit("Error: Please select a valid location.");
}

$allowed_courses = ["C++", "JAVA", "HTML", "Python", "PHP"];

if (!is_array($courses) || count($courses) === 0) {
    exit("Error: Please select at least one course.");
}

$courses = array_values(array_unique($courses));

foreach ($courses as $course) {
    if (
        !is_string($course) ||
        !in_array($course, $allowed_courses, true)
    ) {
        exit("Error: Invalid course selected.");
    }
}

$courseText = implode(", ", $courses);

try {
    $pdo->beginTransaction();

    $account = $pdo->prepare(
        "SELECT id, email, student_id, enrollment_completed
         FROM users
         WHERE id = ? AND role = 'student'
         LIMIT 1
         FOR UPDATE"
    );

    $account->execute([$_SESSION["user_id"]]);
    $user = $account->fetch(PDO::FETCH_ASSOC);

    if (
        !$user ||
        (int)$user["enrollment_completed"] === 1 ||
        $user["student_id"] !== null
    ) {
        $pdo->rollBack();
        exit("This account has already completed enrolment or is invalid.");
    }

    $stmt = $pdo->prepare(
        "INSERT INTO students_full
         (first_name, last_name, email, phone, gender, location, courses)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );

    $stmt->execute([
        $first_name,
        $last_name,
        $user["email"],
        $phone,
        $gender,
        $location,
        $courseText
    ]);

    $studentId = (int)$pdo->lastInsertId();

    $update = $pdo->prepare(
        "UPDATE users
         SET student_id = ?, enrollment_completed = 1
         WHERE id = ?
           AND role = 'student'
           AND student_id IS NULL
           AND enrollment_completed = 0"
    );

    $update->execute([$studentId, $user["id"]]);

    if ($update->rowCount() !== 1) {
        throw new RuntimeException("Unable to link the student account.");
    }

    $pdo->commit();

    $_SESSION["student_id"] = $studentId;
    $_SESSION["enrollment_completed"] = 1;

    header("Location: ../HTMLFiles/index.php");
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log($e->getMessage());
    exit("Unable to save enrolment. Please try again or contact the administrator.");
}
?>