<?php
require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    exit("Error: Invalid request method.");
}

$first_name = trim($_POST["first_name"] ?? "");
$last_name  = trim($_POST["last_name"] ?? "");
$email      = trim($_POST["email"] ?? "");
$phone      = trim($_POST["phone"] ?? "");
$gender     = trim($_POST["gender"] ?? "");
$location   = trim($_POST["location"] ?? "");
$courses    = $_POST["courses"] ?? [];

// First name: letters, spaces, hyphens and apostrophes
if ($first_name === "") {
    exit("Error: First Name is required. Please enter your first name.");
}

if ($last_name === "") {
    exit("Error: Last Name is required. Please enter your last name.");
}

if (!preg_match("/^[a-zA-Z]+$/", $first_name)) {
    exit("Error: First Name must contain letters only.");
}
// Last name
if (!preg_match("/^[a-zA-Z]+$/", $last_name)) {
    exit("Error: Last Name must contain letters only.");
}

// Email

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("Error: Please enter a valid email address.");
}

// Phone: 10 digits, optionally beginning with +
if (!preg_match('/^\+?[0-9]{10}$/', $phone)) {
    exit("Error: Please enter a valid phone number (10 digits).");
}

// Gender
if (!in_array($gender, ["Male", "Female"], true)) {
    exit("Error: Please select a valid gender.");
}

// Location: accept the exact values used by the HTML form
$allowed_locations = ["Dandenong", "Frankston", "Berwick"];

if (!in_array($location, $allowed_locations, true)) {
    exit("Error: Please select a valid location.");
}

// Courses
$allowed_courses = ["C++", "JAVA", "HTML", "Python", "PHP"];

if (!is_array($courses) || count($courses) === 0) {
    exit("Error: Please select at least one course.");
}

$courses = array_values(array_unique($courses));

foreach ($courses as $course) {
    if (!is_string($course) ||
        !in_array($course, $allowed_courses, true)) {
        exit("Error: Invalid course selected.");
    }
}

$courseText = implode(", ", $courses);

try {
    // Check whether this email already exists
    $check = $pdo->prepare(
        "SELECT id FROM students_full WHERE email = ? LIMIT 1"
    );
    $check->execute([$email]);

    if ($check->fetch()) {
        exit(
            "Error: This email is already registered. " .
            "Please use another email."
        );
    }

    // Insert using a prepared statement
    $sql = "INSERT INTO students_full
        (first_name, last_name, email, phone, gender, location, courses)
        VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $first_name,
        $last_name,
        $email,
        $phone,
        $gender,
        $location,
        $courseText
    ]);

    echo "<h2>Student registered successfully!</h2>";
    echo '<p><a href="../HTMLFiles/enrolment.html">Back to enrolment form</a></p>';
    echo '<p><a href="students.php">View Student Details</a></p>';

} catch (PDOException $e) {
    // MySQL duplicate-key error
    if ($e->getCode() === "23000" ||
        (isset($e->errorInfo[1]) && (int)$e->errorInfo[1] === 1062)) {
        exit(
            "Error: This email or another unique field is already registered."
        );
    }

    error_log($e->getMessage());
    exit("Error: Unable to save student details. Please check the database.");
}
?>