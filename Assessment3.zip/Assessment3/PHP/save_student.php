<?php

require_once __DIR__ . "/setting.php";

/* 1. Allow POST requests only */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    exit("Error: Invalid request method.");
}

/* 2. Get form data */
$first_name = trim($_POST["fname"] ?? "");
$last_name  = trim($_POST["lname"] ?? "");
$email      = trim($_POST["email"] ?? "");
$phone      = trim($_POST["phone"] ?? "");
$gender     = trim($_POST["gender"] ?? "");
$location   = trim($_POST["Location"] ?? "");
$course     = $_POST["course"] ?? [];

/* 3. Allowed values */
$allowed_genders = ["Male", "Female"];

$allowed_locations = [
    "Dandenong",
    "Frankston",
    "Berwick"
];

$allowed_courses = [
    "C++",
    "JAVA",
    "HTML",
    "Python",
    "PHP"
];

/* 4. Validate first name */
if ($first_name === "") {
    exit("Error: First Name is required.");
}

if (mb_strlen($first_name) > 100) {
    exit("Error: First Name is too long.");
}

if (!preg_match("/^[\p{L}\p{M} '-]+$/u", $first_name)) {
    exit("Error: First Name contains invalid characters.");
}

/* 5. Validate last name */
if ($last_name === "") {
    exit("Error: Last Name is required.");
}

if (mb_strlen($last_name) > 100) {
    exit("Error: Last Name is too long.");
}

if (!preg_match("/^[\p{L}\p{M} '-]+$/u", $last_name)) {
    exit("Error: Last Name contains invalid characters.");
}

/* 6. Validate email */
if ($email === "") {
    exit("Error: Email is required.");
}

if (strlen($email) > 254 ||
    !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("Error: Please enter a valid email address.");
}

/* 7. Validate phone */
if ($phone === "") {
    exit("Error: Phone number is required.");
}

if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $phone)) {
    exit("Error: Please enter a valid phone number.");
}

/* 8. Validate gender */
if ($gender === "") {
    exit("Error: Please select a gender.");
}

if (!in_array($gender, $allowed_genders, true)) {
    exit("Error: Invalid gender selected.");
}

/* 9. Validate location */
if ($location === "") {
    exit("Error: Please select a location.");
}

if (!in_array($location, $allowed_locations, true)) {
    exit("Error: Invalid location selected.");
}

/* 10. Validate courses */
if (!is_array($course)) {
    exit("Error: Invalid course selection.");
}

if (count($course) === 0) {
    exit("Error: Please select at least one course.");
}

foreach ($course as $selected_course) {
    if (
        !is_string($selected_course) ||
        !in_array($selected_course, $allowed_courses, true)
    ) {
        exit("Error: Invalid course selected.");
    }
}

/* Remove duplicate selections and convert to string */
$course = array_values(array_unique($course));
$course_string = implode(", ", $course);

/* 11. Check for duplicate email */
$check = mysqli_prepare(
    $conn,
    "SELECT student_id FROM students WHERE email = ?"
);

if (!$check) {
    exit("Error: Could not prepare email check.");
}

mysqli_stmt_bind_param($check, "s", $email);

if (!mysqli_stmt_execute($check)) {
    mysqli_stmt_close($check);
    exit("Error: Could not check email.");
}

mysqli_stmt_store_result($check);

if (mysqli_stmt_num_rows($check) > 0) {
    mysqli_stmt_close($check);
    exit("Error: This email is already registered.");
}

mysqli_stmt_close($check);

/* 12. Insert student into database */
$sql = "INSERT INTO students
        (first_name, last_name, email, phone, gender, location, course)
        VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    exit("Error: Could not prepare registration.");
}

mysqli_stmt_bind_param(
    $stmt,
    "sssssss",
    $first_name,
    $last_name,
    $email,
    $phone,
    $gender,
    $location,
    $course_string
);

/* 13. Save student */
if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    header("Location: ../HTMLFiles/success.html");
    exit();
}

/* Handle database errors */
$error_number = mysqli_stmt_errno($stmt);

mysqli_stmt_close($stmt);
mysqli_close($conn);

if ($error_number === 1062) {
    exit("Error: This email is already registered.");
}
exit("Error: Registration failed. Please try again.");

?>