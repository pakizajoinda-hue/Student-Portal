<?php
require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    exit("Invalid request.");
}

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    exit("Invalid student ID.");
}

try {
    $stmt = $pdo->prepare(
        "DELETE FROM students_full WHERE id = ?"
    );

    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        $message = "Student deleted successfully!";
        $success = true;
    } else {
        $message = "Student was not found or could not be deleted.";
        $success = false;
    }
} catch (PDOException $e) {
    $message = "Unable to delete student details.";
    $success = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">
    <title>Delete Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 100px;
        }

        .success {
            color: green;
            font-size: 24px;
            font-weight: bold;
        }

        .error {
            color: red;
            font-size: 20px;
            font-weight: bold;
        }

        a {
            display: inline-block;
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <?php if ($success): ?>
        <h2 class="success">
            <?= htmlspecialchars($message) ?>
        </h2>
    <?php else: ?>
        <h2 class="error">
            <?= htmlspecialchars($message) ?>
        </h2>
    <?php endif; ?>

    <p>
        <a href="students.php">Back to Student Details</a>
    </p>

</body>
</html>