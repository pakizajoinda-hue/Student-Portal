<?php
require_once "auth.php";
requireAdmin();
require_once "db.php";

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    http_response_code(400);
    exit("Invalid student ID.");
}

$message = "";
$success = false;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    validateCsrf();
    $postedId = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);
    if (!$postedId || $postedId !== $id) {
        http_response_code(400);
        exit("Invalid student ID.");
    }
    try {
        $stmt = $pdo->prepare("DELETE FROM students_full WHERE id = ?");
        $stmt->execute([$id]);
        $success = $stmt->rowCount() === 1;
        $message = $success ? "Student deleted successfully." : "Student was not found.";
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $message = "Unable to delete student details.";
    }
} elseif ($_SERVER["REQUEST_METHOD"] !== "GET") {
    http_response_code(405);
    header("Allow: GET, POST");
    exit("Method not allowed.");
}
function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8"); }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Delete Student</title>
    </head>
<body>
<?php if ($_SERVER["REQUEST_METHOD"] === "GET"): ?>
    <h2>Confirm student deletion</h2>
    <p>This action permanently deletes this student and linked results/accounts.</p>
    <form method="post" action="delete_student.php?id=<?= (int)$id ?>">
        <input type="hidden" name="id" value="<?= (int)$id ?>">
        <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">
        <button type="submit">Confirm Delete</button>
    </form>
<?php else: ?>
    <h2><?= h($message) ?></h2>
<?php endif; ?>
<p><a href="students.php">Back to Student Details</a></p>
</body>
</html>
