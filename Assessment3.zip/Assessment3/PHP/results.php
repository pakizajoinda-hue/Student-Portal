<?php
require_once "auth.php";
requireAdmin();
require_once "db.php";

$message = "";
$error = "";

/* Show success message */
if (isset($_GET["updated"])){
    $message = "Result updated successfully.";
}
if (isset($_GET["success"])) {
    $message = "Result saved successfully.";
}

/* Save student result */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    validateCsrf();
    $student_id = filter_input(
        INPUT_POST,
        "student_id",
        FILTER_VALIDATE_INT
    );

    $course_name = trim($_POST["course_name"] ?? "");
    $marks_input = trim($_POST["marks"] ?? "");

    if (!$student_id || $student_id < 1) {
        $error = "Please select a valid student.";
    } elseif ($course_name === "") {
        $error = "Please enter a course name.";
    } elseif (
        $marks_input === "" ||
        !is_numeric($marks_input) ||
        (float)$marks_input < 0 ||
        (float)$marks_input > 100
    ) {
        $error = "Marks must be a number between 0 and 100.";
    } else {
        try {
            /* Check student */
            $check = $pdo->prepare(
                "SELECT id FROM students_full WHERE id = ?"
            );
            $check->execute([$student_id]);

            if (!$check->fetch()) {
                $error = "Student not found.";
            } else {
                /* Check duplicate result */
                $check = $pdo->prepare(
                "SELECT result_id FROM results
                WHERE student_id = ? AND course_name = ?"
);
                $check->execute([$student_id, $course_name]);

                if ($check->fetch()) {
                    $error = "This student's result for this course already exists.";
                } else {
                    /* Insert result */
                    $stmt = $pdo->prepare(
                        "INSERT INTO results
                         (student_id, course_name, marks)
                         VALUES (?, ?, ?)"
                    );

                    $stmt->execute([
                        $student_id,
                        $course_name,
                        (float)$marks_input
                    ]);

                    header("Location: results.php?success=1");
                    exit;
                }
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = "Unable to save result. Please try again.";
        }
    }
}

/* Get students */
try {
    $students = $pdo->query(
        "SELECT id, first_name, last_name FROM students_full ORDER BY first_name"
    )->fetchAll(PDO::FETCH_ASSOC);

/* Get results */
$sql = "SELECT r.result_id, r.student_id,
               s.first_name, s.last_name,
               r.course_name, r.marks,
               r.created_at, r.updated_at
        FROM results r
        INNER JOIN students_full s ON r.student_id = s.id
        ORDER BY r.result_id ASC";

$results = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit("Unable to load student results. Please try again later.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
    <link rel="stylesheet" href="../CSSFiles/style.css">
</head>
<body>

<h1>Student Results</h1>

<?php if ($message !== ""): ?>
    <p style="color: darkblue;"><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<?php if ($error !== ""): ?>
    <p><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<h2>Add Student Result</h2>

<form method="POST" action="results.php">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, "UTF-8") ?>">
    <label for="student_id">Student</label>
    <select name="student_id" id="student_id">
        <option value="">Select Student</option>
        <?php foreach ($students as $student): ?>
            <option value="<?= (int)$student['id'] ?>">
                <?= htmlspecialchars(
                    $student['first_name'] . " " . $student['last_name']
                ) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <br><br>

    <label for="course_name">Course Name</label>
    <input type="text" name="course_name" id="course_name">

    <br><br>

    <label for="marks">Marks (0–100)</label>
    <input type="number" name="marks" id="marks"
           min="0" max="100" step="any">

    <br><br>
    <button type="submit">Save Result</button>
</form>

<h2>All Student Results</h2>

<?php if (count($results) > 0): ?>
<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>Result ID</th>
            <th>Student ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Course</th>
            <th>Marks</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($results as $result): ?>
        <tr>
            <td><?= (int)$result['result_id'] ?></td>
            <td><?= (int)$result['student_id'] ?></td>
            <td><?= htmlspecialchars($result['first_name']) ?></td>
            <td><?= htmlspecialchars($result['last_name']) ?></td>
            <td><?= htmlspecialchars($result['course_name']) ?></td>
            <td><?= htmlspecialchars((string)$result['marks']) ?></td>
            <td><?= htmlspecialchars($result['created_at'] ?? '') ?></td>
            <td><?= htmlspecialchars($result['updated_at'] ?? '') ?></td>
            <td>
                <a href="edit_result.php?id=<?= (int)$result['result_id'] ?>">Edit</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
    <p>No results have been recorded yet.</p>
<?php endif; ?>

<p><a href="../HTMLFiles/index.html">Back to Dashboard</a></p>

</body>
</html>