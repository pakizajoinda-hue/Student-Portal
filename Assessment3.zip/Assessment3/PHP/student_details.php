<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <link rel="stylesheet" href="../CSSFiles/desktop.css" media="screen and (min-width:1025px)" />
    <link rel="stylesheet" href="../CSSFiles/mobile.css" media="screen and (max-width:600px)" />
    <link rel="stylesheet" href="../CSSFiles/tablet.css"  media="screen and (min-width:601px) and (max-width:768px)"/>
    <title> Student Portal</title>
    <link  rel="icon" href="../Images/logo1.png" type="image/x-icon">
    
</head>

<body>
    <?php
require_once "../PHP/setting.php";

$sql = "SELECT first_name, last_name, email, phone, gender, location, course
        FROM students
        ORDER BY student_id DESC";

$result = mysqli_query($conn, $sql);

if (!$result) {
    exit("Error loading student details.");
}
?>
        <header class="mobile-header">
        <input class="menu-chkbx" type="checkbox" id="menu-chkbx" hidden/>
        <label class="menu-burger" for="menu-chkbx">
            <span class="hamburger" hidden></span></label>
        <nav class="main-nav">
            <ul class="nav-list">

                <li class="logo"></li>
                <img src="../Images/logo.png" alt="Logo" width="106">
                </li>
                <li class="search"><a href="search.html">
                        <img src="../Images/iconsearch.png" alt="search" width="20"></a></li>
                </li>
                <li class="dashboard"><a href="index.html"> Dashboard </a></li>
                <li><a href="enrolment.html">Enrolment </a></li>
                <li><a href="student_details.php"> Student Details </a></li>
                <li><a href="results.html"> Results </a></li>
                <li><a href="Support.html"> Support </a></li>
                <li class="dropdown">
                    <details>
                        <summary>PG</summary>
                        <ul class="dropdown-menu">
                            <li>Profile</li>
                            <li>Grand</li>
                            <li>Calandar</li>
                            <li>Message</li>
                            <li>Report</li>
                            <li>Log Out</li>

                        </ul>
                    </details>
                </li>
            </ul>
    </nav></header>
    </div>

    <!-- Students Details -->

    <section class="details">
        <nav class="meunSD">
            <h1>PG</h1>
            <h2>👋
                <?php
$student = mysqli_fetch_assoc($result);

if ($student) {
    echo htmlspecialchars(
        $student["first_name"] . " " . $student["last_name"]
    );
} else {
    echo "Student not found";
}
?>
            </h2>

        </nav>
        <div class="student_detalis">
            <p class="user">User details</p><br>
            <p class="email">Email address</p><br>
            <p class="s20"><a href="email.html"> s202501378@my.chisholm.edu.au</a></p>
            <p class="vis">(Visible to course paraticipants)</p>
        </div>

        <div class="course_details">
            Course details<br>
            Course profiles<br>
            Your courses<br>
            <a href="../HTMLFiles/tertairy.html">Tertiary Access Program</a><br>
            <a href="../HTMLFiles/ITS101.html"> ITS101: Information System (25-2026)</a><br>
            <a href="../HTMLFiles/ITS102.html">ITS102: Programming Environment (25-2026)</a><br>
            <a href="../HTMLFiles/ITS103.html">ITS103: Database Fundamentals (25-2026)</a><br>
            <a href="../HTMLFiles/ITS104.html">ITS104: Introduction to Cyber Security (25-2026)</a><br>
            <a href="../HTMLFiles/ITS201.html"> ITS201: Inside Information Technology (25-2026)</a><br>
            <a href="../HTMLFiles/ITS202.html">ITS202: Math Foundation for Computing (25-2026)</a><br>
            <a href="../HTMLFiles/ITS203.html">ITS203: System and Network Administration (25-2026)</a><br>
            <a href="../HTMLFiles/ITS204.html">ITS204: Web Technology and Full-Stack Fundation (25-2026)</a></p><br>


        </div>
        <div class="certificates">
            <p>Certificates<br>
                Your Certificates<br>
                Your Diploma<br>
                Your courses<br>
                Form<br>
                Post Form<br>
                MyCertificate
            </p>
        </div>


        <div class="report">
            <p>Reports<br>
                Browser sessions<br>
                Grades overview<br>

            </p>
        </div>


        <div class="login">
            <p>Login activity<br>
                First access to site<br>
                Saturday, 9 November 2024, 12:21 AM (1 year 295 days)<br>
                Last access to site 
                Monday, 6 September 2026, 12:30 PN (now)
            </p>
        </div>

    </section>
<script src="../JavaScriptFiles/javaScript.js"></script>
    </div>
</body>

</html>