<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSSFiles/style.css" />
    <link rel="stylesheet" href="../CSSFiles/desktop.css" media="screen and (min-width:1025px)" />
    <link rel="stylesheet" href="../CSSFiles/mobile.css" media="screen and (max-width:600px)" />
    <link rel="stylesheet" href="../CSSFiles/tablet.css"  media="screen and (min-width:601px) and (max-width:768px)"/>
    <title> Student Portal</title>
    <link  rel="icon" href="../Images/logo1.png" type="image/x-icon">
    
</head>

<body>
       <section class="details">
        <nav class="meunSD">
            <h1>👋</h1>
            <h2>Welcome to Login page!</h2>

        </nav>
    

    <!-- Login Details -->

   
</body>

</html>