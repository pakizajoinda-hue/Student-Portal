<?php
require_once "auth.php";
require_once "db.php";

$message = "";

if (isset($_GET["registered"])) {
    $message = "Registration successful. Please log in.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    validateCsrf();
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    // Validate input using PHP.
    if ($email === "" || $password === "") {
        $message = "Please enter your email and password.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
    } else {
        try {
            $stmt = $pdo->prepare(
                "SELECT id, student_id, email, password_hash,
                        role, enrollment_completed
                 FROM users
                 WHERE email = ?
                 LIMIT 1"
            );

            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (
                $user &&
                password_verify($password, $user["password_hash"])
            ) {
                session_regenerate_id(true);

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["role"] = $user["role"];
                $_SESSION["student_id"] = $user["student_id"];
                $_SESSION["enrollment_completed"] =(int)$user["enrollment_completed"];
                $_SESSION["student_name"] = "";
                if (
                    $user["role"] === "student" &&
                     !empty($user["student_id"])
                    ) {
                $nameStmt = $pdo->prepare(
                 "SELECT first_name, last_name
                  FROM students_full
                  WHERE id = ?
                  LIMIT 1"
    );

                 $nameStmt->execute([$user["student_id"]]);
                 $student = $nameStmt->fetch(PDO::FETCH_ASSOC);

                if ($student) {
                   $_SESSION["student_name"] = $student["first_name"];
                   $_SESSION["student_full_name"] =
                   $student["first_name"] . " " . $student["last_name"];
    }
}


                if ($user["role"] === "admin") {
                    header("Location: students.php");
                    exit;
                }

                if ((int)$user["enrollment_completed"] === 1) {
                    header("Location: ../HTMLFiles/index.html");
                    exit;
                }

                header("Location: ../HTMLFiles/enrolment.html");
                exit;
            }

            $message = "Invalid email or password.";
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $message = "Unable to log in. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Portal Login</title>
</head>
<body>
    <h2>Student Portal Login</h2>

    <?php if ($message !== ""): ?>
        <p><?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?></p>
    <?php endif; ?>

    <form method="post" action="login.php">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, "UTF-8") ?>">
        <label>Email</label><br>
        <input type="text" name="email"><br><br>

        <label>Password</label><br>
        <input type="password" name="password"><br><br>

        <button type="submit">Login</button>
    </form>

    <p><a href="register.php">Create student account</a></p>
</body>
</html>