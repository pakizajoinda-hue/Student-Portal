<?php
require_once "auth.php";
require_once "db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    validateCsrf();
    $first_name = trim($_POST["first_name"] ?? "");
    $last_name = trim($_POST["last_name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    // Validate all fields using PHP.
    if (
        $first_name === "" ||
        $last_name === "" ||
        $email === "" ||
        $password === ""
    ) {
        $message = "All fields are required.";
    } elseif (
        !preg_match("/^[a-zA-Z]+$/", $first_name) ||
        !preg_match("/^[a-zA-Z]+$/", $last_name)
    ) {
        $message = "First name and last name must contain English letters only.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
    } elseif (strlen($password) < 8) {
        $message = "Password must be at least 8 characters.";
    } else {
        try {
            $check = $pdo->prepare(
                "SELECT id FROM users WHERE email = ? LIMIT 1"
            );
            $check->execute([$email]);

            if ($check->fetch()) {
                $message = "This email already has an account.";
            } else {
                $checkStudent = $pdo->prepare(
                    "SELECT id FROM students_full WHERE email = ? LIMIT 1"
                );
                $checkStudent->execute([$email]);

                if ($checkStudent->fetch()) {
                    $message = "This email is already used for a student record. Please contact the administrator.";
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);

                    $stmt = $pdo->prepare(
                        "INSERT INTO users
                         (student_id, email, password_hash, role, enrollment_completed)
                         VALUES (NULL, ?, ?, 'student', 0)"
                    );

                    $stmt->execute([$email, $hash]);

                    header("Location: login.php?registered=1");
                    exit;
                }
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $message = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Registration</title>
</head>
<body>
    <h2>Create Student Account</h2>

    <?php if ($message !== ""): ?>
        <p><?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?></p>
    <?php endif; ?>

    <form method="post" action="register.php">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, "UTF-8") ?>">
        <label for="first_name">First Name</label><br>
        <input id="first_name" name="first_name"><br><br>

        <label for="last_name">Last Name</label><br>
        <input id="last_name" name="last_name"><br><br>

        <label for="email">Email</label><br>
        <input id="email" name="email" type="text"><br><br>

        <label for="password">Password (minimum 8 characters)</label><br>
        <input id="password" name="password" type="password"><br><br>

        <button type="submit">Register</button>
    </form>

      <p>
        <a href="../PHP/students.php">
            Back to Student Details
        </a>
    </p>
 
    <p>
        <a href="../PHP/results.php">
            Back to Result
        </a>
    </p>
    <p><a href="../HTMLFiles/index.html">
        Back to Dashboard</a></p>
         <p>
        <a href="../PHP/logout.php">
            Logout 
        </a>
    </p>
</body>
</html>