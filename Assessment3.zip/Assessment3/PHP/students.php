<?php
require_once "auth.php";
requireAdmin();
require_once "db.php";
$students = [];

try {
    $stmt = $pdo->query(
        "SELECT id, first_name, last_name, email, phone,
                gender, location, courses, created_at
         FROM students_full
         ORDER BY id ASC"
    );

    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log($e->getMessage());
    exit("Unable to load student details.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details</title>

    <link rel="stylesheet" href="../CSSFiles/style.css">

    <style>
        .students-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .students-table th,
        .students-table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
            overflow-wrap: anywhere;
        }

        .students-table th {
            background: #172033;
            color: white;
        }

        .table-container {
            overflow-x: auto;
            padding: 20px;
        }

        .students-table a {
            margin-right: 8px;
        }
    </style>
</head>

<body>

<main class="table-container">

    <h1>Student Details</h1>
   

    <?php if (count($students) > 0): ?>

        <table class="students-table">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Gender</th>
                    <th>Location</th>
                    <th>Courses</th>
                    <th>Created At</th>
                    <th>Action</th>

                </tr>
            </thead>

            <tbody>

                <?php foreach ($students as $student): ?>

                    <tr>
                        <td>
                            <?= htmlspecialchars((string)$student['id']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['first_name']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['last_name']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['email']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['phone']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['gender']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['location']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['courses']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($student['created_at']) ?>
                        </td>

                        <td>
                            <a href="edit_student.php?id=<?= (int)$student['id'] ?>">
                                Edit
                            </a>

                            |

                            <a
                                href="delete_student.php?id=<?= (int)$student['id'] ?>"
                                onclick="return confirm('Are you sure you want to delete this student?');"
                            >
                                Delete
                            </a>
                        </td>
                    </tr>

                <?php endforeach; ?>

            </tbody>

        </table>

    <?php else: ?>

        <p>No students registered yet.</p>

    <?php endif; ?>

    <p>
        <a href="../PHP/register.php">
            Back to register
        </a>
    </p>
    <p>
        <a href="../PHP/results.php">
            Back to Result
        </a>
    </p>
    <p><a href="../HTMLFiles/index.php">
        Back to Dashboard</a></p>
         <p>
        <a href="../PHP/logout.php">
            Logout 
        </a>
    </p>
</main>

</body>
</html>