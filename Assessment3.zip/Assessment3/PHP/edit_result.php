<?php
require_once "auth.php";
requireAdmin();
require_once "db.php";

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    exit("Invalid result ID.");
}

$error = "";

$stmt = $pdo->prepare(
    "SELECT r.result_id, r.student_id, r.course_name,
            r.marks, s.first_name, s.last_name
     FROM results r
     INNER JOIN students_full s ON r.student_id = s.id
     WHERE r.result_id = ?"
);
$stmt->execute([$id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$result) {
    exit("Result not found.");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    validateCsrf();
    $marks = trim($_POST["marks"] ?? "");

    if (
        $marks === "" ||
        !is_numeric($marks) ||
        (float)$marks < 0 ||
        (float)$marks > 100
    ) {
        $error = "Marks must be between 0 and 100.";
    } else {
        try {
            $update = $pdo->prepare(
                "UPDATE results
                 SET marks = ?, updated_at = NOW()
                 WHERE result_id = ?"
            );

            $update->execute([
                (float)$marks,
                $id
            ]);

            header("Location: results.php?updated=1");
            exit;

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = "Unable to update result.";
        }
    }
}

function h($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Edit Student Result</title>

    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            width: 320px;
            margin: 60px auto;
        }

        h1 {
            text-align: center;
        }

        input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            margin: 8px 0 18px;
        }

        button {
            padding: 8px 15px;
            cursor: pointer;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Edit Student Result</h1>

    <?php if ($error !== ""): ?>
        <p class="error"><?= h($error) ?></p>
    <?php endif; ?>

    <form method="POST"
          action="edit_result.php?id=<?= (int)$id ?>">
        <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">

        <label>Student Name</label>
        <input type="text"
               value="<?= h(
                   $result["first_name"] . " " .
                   $result["last_name"]
               ) ?>"
               readonly>

        <label>Course Name</label>
        <input type="text"
               value="<?= h($result["course_name"]) ?>"
               readonly>

        <label>Marks (0–100)</label>
        <input type="number"
               name="marks"
               min="0"
               max="100"
               step="any"
               value="<?= h(
                   $_POST["marks"] ?? $result["marks"]
               ) ?>"
>

        <button type="submit">
            Save Changes
        </button>

        <a href="results.php">Cancel</a>

    </form>

</div>

</body>
</html>