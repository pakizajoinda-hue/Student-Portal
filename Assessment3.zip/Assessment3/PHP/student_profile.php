<?php
require_once "auth.php";
require_once "db.php";

header("Content-Type: application/json; charset=utf-8");

requireStudent();

try {
    $stmt = $pdo->prepare(
        "SELECT s.first_name, s.last_name, s.email
         FROM users u
         INNER JOIN students_full s ON s.id = u.student_id
         WHERE u.id = ?
           AND u.role = 'student'
           AND u.enrollment_completed = 1
         LIMIT 1"
    );

    $stmt->execute([$_SESSION["user_id"]]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        http_response_code(404);
        echo json_encode([
            "error" => "Student profile not found"
        ]);
        exit;
    }

    echo json_encode([
        "first_name" => $student["first_name"],
        "last_name" => $student["last_name"],
        "full_name" => $student["first_name"] . " " . $student["last_name"],
        "email" => $student["email"]
    ]);

} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);

    echo json_encode([
        "error" => "Unable to load student profile"
    ]);
}