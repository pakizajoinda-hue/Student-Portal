<?php
require_once "db.php";

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    exit("Invalid student ID.");
}

try {
    $stmt = $pdo->prepare(
        "SELECT * FROM students_full WHERE id = ?"
    );
    $stmt->execute([$id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        exit("Student not found.");
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $first_name = trim($_POST["first_name"] ?? "");
        $last_name = trim($_POST["last_name"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $phone = trim($_POST["phone"] ?? "");
        $gender = $_POST["gender"] ?? "";
        $location = $_POST["location"] ?? "";
        $courses = $_POST["courses"] ?? [];

        if (
            $first_name === "" ||
            $last_name === "" ||
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            $phone === "" ||
            !in_array($gender, ["Male", "Female"], true) ||
            !in_array($location, ["dandy", "frankston", "berwick"], true) ||
            !is_array($courses) ||
            count($courses) === 0 ||
            count(array_diff($courses, ["C++", "JAVA", "HTML", "Python", "PHP"])) > 0
        ) {
            exit("Please enter valid details and select at least one course.");
        }

        $courseText = implode(", ", $courses);
$check = $pdo->prepare(
    "SELECT id FROM students_full
     WHERE LOWER(email) = LOWER(?)
       AND id <> ?
     LIMIT 1"
);

$check->execute([$email, $id]);

if ($check->fetch(PDO::FETCH_ASSOC)) {
    exit("Error: This email is already registered to another student.");
}
        $update = $pdo->prepare(
            "UPDATE students_full
             SET first_name = ?, last_name = ?, email = ?,
                 phone = ?, gender = ?, location = ?, courses = ?
             WHERE id = ?"
        );

        $update->execute([
            $first_name,
            $last_name,
            $email,
            $phone,
            $gender,
            $location,
            $courseText,
            $id
        ]);

        header("Location: students.php");
        exit;
    }

} catch (PDOException $e) {
    exit("Unable to process student details.");
}

$selectedCourses = array_map(
    "trim",
    explode(",", $student["courses"] ?? "")
);

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
</head>
<body>

<h1>Edit Student</h1>

<form method="POST" action="edit_student.php?id=<?= (int)$id ?>">

    <label>First Name</label><br>
    <input type="text" name="first_name"
           value="<?= h($student['first_name']) ?>" required><br><br>

    <label>Last Name</label><br>
    <input type="text" name="last_name"
           value="<?= h($student['last_name']) ?>" required><br><br>

    <label>Email</label><br>
    <input type="email" name="email"
           value="<?= h($student['email']) ?>" required><br><br>

    <label>Phone</label><br>
    <input type="tel" name="phone"
           value="<?= h($student['phone']) ?>" required><br><br>

    <label>Gender</label><br>
    <label>
        <input type="radio" name="gender" value="Male"
            <?= $student['gender'] === 'Male' ? 'checked' : '' ?> required>
        Male
    </label>

    <label>
        <input type="radio" name="gender" value="Female"
            <?= $student['gender'] === 'Female' ? 'checked' : '' ?>>
        Female
    </label><br><br>

    <label>Location</label><br>
    <select name="location" required>
        <option value="dandy"
            <?= $student['location'] === 'dandy' ? 'selected' : '' ?>>
            Dandenong
        </option>
        <option value="frankston"
            <?= $student['location'] === 'frankston' ? 'selected' : '' ?>>
            Frankston
        </option>
        <option value="berwick"
            <?= $student['location'] === 'berwick' ? 'selected' : '' ?>>
            Berwick
        </option>
    </select><br><br>

    <label>Courses</label><br>
    <?php foreach (["C++", "JAVA", "HTML", "Python", "PHP"] as $course): ?>
        <label>
            <input type="checkbox" name="courses[]"
                   value="<?= h($course) ?>"
                <?= in_array($course, $selectedCourses, true) ? 'checked' : '' ?>>
            <?= h($course) ?>
        </label><br>
    <?php endforeach; ?>

    <br>
    <button type="submit">Save Changes</button>
    <a href="students.php">Cancel</a>

</form>

</body>
</html>