<?php
require_once "auth.php";
requireAdmin();
require_once "db.php";

// Validate student ID
$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    exit("Error: Invalid student ID.");
}

function h($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

$allowed_courses = ["C++", "JAVA", "HTML", "Python", "PHP"];

$allowed_locations = [
    "dandy",
    "frankston",
    "berwick"
];

try {
    // Get existing student
    $stmt = $pdo->prepare(
        "SELECT id, first_name, last_name, email,
                phone, gender, location, courses
         FROM students_full
         WHERE id = ?"
    );

    $stmt->execute([$id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        exit("Error: Student not found.");
    }

    // Process form submission
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        validateCsrf();

        $email = trim($_POST["email"] ?? "");
        $phone = trim($_POST["phone"] ?? "");
        $gender = trim($_POST["gender"] ?? "");
        $location = trim($_POST["location"] ?? "");
        $courses = $_POST["courses"] ?? [];

        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            exit("Error: Please enter a valid email address.");
        }

        // Validate phone
        if (!preg_match('/^\+?[0-9]{10}$/', $phone)) {
            exit("Error: Phone must contain exactly 10 digits, optionally preceded by +.");
        }

        // Validate gender
        if (!in_array($gender, ["Male", "Female"], true)) {
            exit("Error: Please select a valid gender.");
        }

        // Validate location
        if (!in_array($location, $allowed_locations, true)) {
            exit("Error: Please select a valid location.");
        }

        // Validate courses
        if (!is_array($courses)) {
            exit("Error: Invalid course selection.");
        }

        $courses = array_values(array_unique($courses));

        if (count($courses) === 0) {
            exit("Error: Please select at least one course.");
        }

        foreach ($courses as $course) {
            if (
                !is_string($course) ||
                !in_array($course, $allowed_courses, true)
            ) {
                exit("Error: Invalid course selected.");
            }
        }

        // Check whether another student uses this email
        $check = $pdo->prepare(
            "SELECT id
             FROM students_full
             WHERE LOWER(email) = LOWER(?)
               AND id <> ?
             LIMIT 1"
        );

        $check->execute([$email, $id]);

        if ($check->fetch(PDO::FETCH_ASSOC)) {
            exit(
                "Error: This email is already registered to another student."
            );
        }

        // Store selected courses as comma-separated text
        $courseText = implode(", ", $courses);

        // Update editable fields only
        $update = $pdo->prepare(
            "UPDATE students_full
             SET email = ?,
                 phone = ?,
                 gender = ?,
                 location = ?,
                 courses = ?
             WHERE id = ?"
        );

        $update->execute([
            $email,
            $phone,
            $gender,
            $location,
            $courseText,
            $id
        ]);

        header("Location: students.php");
        exit;
    }

} catch (PDOException $e) {
    error_log($e->getMessage());
    exit("Error: Unable to process student details. Check the database.");
}

// Prepare previously selected courses
$selectedCourses = array_filter(
    array_map(
        "trim",
        explode(",", $student["courses"] ?? "")
    ),
    function ($course) {
        return $course !== "";
    }
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="../CSSFiles/style.css">
</head>
<body>

<h1 style="text-align: center; transform: translateX(-3%);">Edit Student</h1>
<form method="POST"
      action="edit_student.php?id=<?= (int)$id ?>">
    <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">

    <label for="first_name">First Name</label><br>
    <input
        type="text"
        id="first_name"
        value="<?= h($student['first_name']) ?>"
        readonly
    ><br><br>

    <label for="last_name">Last Name</label><br>
    <input
        type="text"
        id="last_name"
        value="<?= h($student['last_name']) ?>"
        readonly
    ><br><br>

    <label for="email">Email</label><br>
    <input
        type="email"
        name="email"
        id="email"
        value="<?= h($student['email']) ?>"
    ><br><br>

    <label for="phone">Phone</label><br>
    <input
        type="tel"
        name="phone"
        id="phone"
        value="<?= h($student['phone']) ?>"
        pattern="\+?[0-9]{10}"
        title="Enter exactly 10 digits, optionally preceded by +"
    ><br><br>

    <label>Gender</label><br>

    <label>
        <input
            type="radio"
            name="gender"
            value="Male"
            <?= $student['gender'] === 'Male' ? 'checked' : '' ?>
        >
        Male
    </label>

    <label>
        <input
            type="radio"
            name="gender"
            value="Female"
            <?= $student['gender'] === 'Female' ? 'checked' : '' ?>
        >
        Female
    </label>

    <br><br>

    <label for="location">Location</label><br>

    <select name="location" id="location">
        <option
            value="dandy"
            <?= $student['location'] === 'dandy' ? 'selected' : '' ?>
        >
            Dandenong
        </option>

        <option
            value="frankston"
            <?= $student['location'] === 'frankston' ? 'selected' : '' ?>
        >
            Frankston
        </option>

        <option
            value="berwick"
            <?= $student['location'] === 'berwick' ? 'selected' : '' ?>
        >
            Berwick
        </option>
    </select>

    <br><br>

    <label>Courses</label><br>

    <?php foreach ($allowed_courses as $course): ?>
        <label>
            <input
                type="checkbox"
                name="courses[]"
                value="<?= h($course) ?>"
                <?= in_array($course, $selectedCourses, true) ? 'checked' : '' ?>
            >
            <?= h($course) ?>
        </label>
        <br>
    <?php endforeach; ?>

    <br>

    <button type="submit">Save Changes</button>

    <a href="students.php">Cancel</a>

</form>

</body>
</html>