<?php
$host = "localhost";
$user = "root";
$pswd = "";
$dbnm = "student_portal";

$conn = mysqli_connect($host, $user, $pswd, $dbnm, 3307);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>