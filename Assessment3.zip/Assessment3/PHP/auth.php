<?php
// Secure session configuration must be set before session_start().
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set("session.use_strict_mode", "1");
    ini_set("session.use_only_cookies", "1");
    session_set_cookie_params([
        "lifetime" => 0,
        "path" => "/",
        "secure" => !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off",
        "httponly" => true,
        "samesite" => "Lax"
    ]);
    session_start();
}

function requireLogin(): void
{
    if (empty($_SESSION["user_id"]) || empty($_SESSION["role"])) {
        header("Location: login.php");
        exit;
    }
}

function requireAdmin(): void
{
    requireLogin();
    if ($_SESSION["role"] !== "admin") {
        http_response_code(403);
        exit("Access denied.");
    }
}

function requireStudent(): void
{
    requireLogin();
    if ($_SESSION["role"] !== "student") {
        http_response_code(403);
        exit("Access denied.");
    }
}

function csrfToken(): string
{
    if (empty($_SESSION["csrf_token"])) {
        $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
    }
    return $_SESSION["csrf_token"];
}

function validateCsrf(): void
{
    $submitted = $_POST["csrf_token"] ?? "";
    $stored = $_SESSION["csrf_token"] ?? "";
    if (!is_string($submitted) || !is_string($stored) || $stored === "" || !hash_equals($stored, $submitted)) {
        http_response_code(403);
        exit("Invalid or expired form token. Please go back, reload the form, and try again.");
    }
}

function requireEnrolledStudent(): void
{
    requireStudent();
    if (empty($_SESSION["enrollment_completed"]) || (int)$_SESSION["enrollment_completed"] !== 1 || empty($_SESSION["student_id"])) {
        http_response_code(403);
        exit("Please complete your enrolment first.");
    }
}
