document.addEventListener("DOMContentLoaded", function () {

    const menuBurger = document.querySelector(".menu-burger");
    const mainNav = document.querySelector(".main-nav");

    if (menuBurger && mainNav) {

        menuBurger.addEventListener("click", function () {

            if (mainNav.style.display === "block") {
                mainNav.style.display = "none";
            } else {
                mainNav.style.display = "block";
            }

        });
    }

});