document.addEventListener("DOMContentLoaded", function () {

    const inputs = document.querySelectorAll(".input-box input");

    inputs.forEach(function (input) {

        const label = input.previousElementSibling;

        input.addEventListener("focus", function () {
            label.style.transform = "translateY(-28px)";
            label.style.fontSize = "14px";
            input.style.paddingTop = "25px";
            label.style.backgroundColor = "white";
            label.style.padding = "0 5px";
        });

        input.addEventListener("input", function () {

            if (input.value.trim() !== "") {
                label.style.transform = "translateY(-25px)";
                label.style.fontSize = "14px";
                label.style.backgroundColor = "white";
                label.style.padding = "0 5px";
            } else {
                label.style.transform = "";
                label.style.fontSize = "";
                label.style.backgroundColor = "";
                label.style.padding = "";
            }

        });

        input.addEventListener("blur", function () {

            if (input.value.trim() !== "") {
                label.style.transform = "translateY(-25px)";
                label.style.fontSize = "14px";
                label.style.backgroundColor = "white";
                label.style.padding = "0 5px";
            } else {
                label.style.transform = "";
                label.style.fontSize = "";
                label.style.backgroundColor = "";
                label.style.padding = "";
            }

        });

    });

});
function register() {

    let valid = true;

    const fname = document.getElementById("fname");
    const lname = document.getElementById("lname");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");

    document.querySelectorAll(".js-error").forEach(function(error) {
        error.remove();
    });

    if (fname.value.trim() === "") {
        showError(fname, "Please enter your first name.");
        valid = false;
    } else if (!/^[A-Za-z\s'-]+$/.test(fname.value.trim())) {
        showError(fname, "Letters only.");
        valid = false;
    }

    if (lname.value.trim() === "") {
        showError(lname, "Please enter your last name.");
        valid = false;
    } else if (!/^[A-Za-z\s'-]+$/.test(lname.value.trim())) {
        showError(lname, "Letters only.");
        valid = false;
    }

    if (email.value.trim() === "") {
        showError(email, "Please enter your email.");
        valid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        showError(email, "Please enter a valid email.");
        valid = false;
    }

    if (phone.value.trim() === "") {
        showError(phone, "Please enter your phone number.");
        valid = false;
    } else if (!/^[0-9]+$/.test(phone.value.trim())) {
        showError(phone, "Numbers only.");
        valid = false;
    }

    const gender = document.querySelector('input[type="radio"]:checked');

    if (!gender) {
        alert("Please select your gender.");
        valid = false;
    }

    const location = document.querySelector("select");

    if (!location || location.selectedIndex === 0) {
        alert("Please select your location.");
        valid = false;
    }

    const courses = document.querySelectorAll('input[type="checkbox"]:checked');

    if (courses.length === 0) {
        alert("Please select at least one course.");
        valid = false;
    }

    if (!valid) {
        return false;
    }
    alert("Your enrolment has been submitted successfully!");
    window.location.href = "success.html";
    return false;
}

function showError(input, message) {

    const error = document.createElement("span");

    error.className = "js-error";

    error.textContent = message;

    error.style.color = "red";
    error.style.fontSize = "14px";
    error.style.display = "block";
    error.style.marginTop = "5px";

    input.parentElement.appendChild(error);
}
/* This code shows Search on search.html page  */
document.addEventListener("DOMContentLoaded", function () {

    const searchForm = document.getElementById("searchForm");
    const searchInput = document.getElementById("query");

    if (searchForm && searchInput) {
        searchForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const keyword = searchInput.value.trim();

            if (keyword === "") {
                alert("Please enter a keyword.");
                return;
            }

            
        });
    }

});
const pages = [
    { name: "Dashboard", url: "index.html" },
    { name: "Enrolment", url: "enrolment.html" },
    { name: "Student Details", url: "student_details.html" },
    { name: "Results", url: "results.html" },
    { name: "Student Orientation", url: "studentOrintation.html" },
    { name: "Student News", url: "studentNews.html" },
    { name: "ITS101", url: "ITS101.html" },
    { name: "ITS102", url: "ITS102.html" },
    { name: "ITS103", url: "ITS103.html" },
    { name: "ITS104", url: "ITS104.html" },
    { name: "ITS201", url: "ITS201.html" },
    { name: "ITS202", url: "ITS202.html" },
    { name: "ITS203", url: "ITS203.html" },
    { name: "ITS204", url: "ITS204.html" },
    { name: "Tertiary Access Program", url: "tertairy.html" }
];
document.addEventListener("DOMContentLoaded", function () {

    const searchForm = document.getElementById("searchForm");
    const searchInput = document.getElementById("query");
    const searchResults = document.getElementById("searchResults");


    if (searchForm && searchInput && searchResults) {

        searchForm.addEventListener("submit", function (event) {

            event.preventDefault();

            const keyword = searchInput.value.trim().toLowerCase();

            searchResults.innerHTML = "";

            if (keyword === "") {
                searchResults.textContent = "Please enter a keyword.";
                return;
            }

            const matches = pages.filter(function (page) {
                return page.name.toLowerCase().includes(keyword);
            });

            if (matches.length === 0) {
                searchResults.textContent = "No results found.";
                return;
            }

            matches.forEach(function (page) {

                const link = document.createElement("a");

                link.href = page.url;
                link.textContent = page.name;
                link.style.display = "block";
                link.style.marginTop = "10px";

                searchResults.appendChild(link);
            });

        });
    }

});
const searchInput = document.getElementById("courseSearch");
/* This code shows Search on Courses  */
document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("courseSearch");
    const courses = document.querySelectorAll("#container > div");

    if (searchInput) {
        searchInput.addEventListener("input", function () {

            const searchText = searchInput.value.toLowerCase().trim();

            courses.forEach(function (course) {

                const courseText = course.textContent.toLowerCase();

                if (courseText.includes(searchText)) {
                    course.style.display = "";
                } else {
                    course.style.display = "none";
                }

            });

        });
    }

});
const menuCheckbox = document.getElementById("menu-chkbx");
const mainNav = document.querySelector(".main-nav");

menuCheckbox.addEventListener("change", function () {
    if (this.checked) {
        mainNav.style.display = "block";
    } else {
        mainNav.style.display = "none";
    }
});
