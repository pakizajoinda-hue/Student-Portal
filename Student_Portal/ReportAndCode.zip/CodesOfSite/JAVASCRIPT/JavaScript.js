function register() {
            if
                (document.querySelectorAll('input[required]invalid').length > 0) {
                alert("Please fill in all required fields.");
                return false;
            }
            let courses = document.querySelectorAll('input[name="course"]:checked');
            if (courses.length === 0) {
                alert("Please select at least one course.");
                return false;
            }
            window.location.href = "success.html";
            return false;
           
        }
  